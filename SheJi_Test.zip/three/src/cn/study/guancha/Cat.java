package cn.study.guancha;

import java.util.ArrayList;
import java.util.List;

//����������
class Cat implements Subject {

    private List<Observer> observers = new ArrayList<>();

    @Override
    public void attach(Observer o) {
        observers.add(o);
    }

    @Override
    public void detach(Observer o) {
        observers.remove(o);
    }

    @Override
    public void notifyObserver() {
        for(Observer o : observers) {
            o.update();
        }
    }

    //è�з���
    public void shout() {
        System.out.println("è���һ��!");
        notifyObserver();
    }
}