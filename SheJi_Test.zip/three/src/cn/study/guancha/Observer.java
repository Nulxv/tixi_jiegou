package cn.study.guancha;

//�۲��߽ӿ�
interface Observer {
    void update();
}
