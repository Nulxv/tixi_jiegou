package cn.study.guancha;

public class Client {
    public static void main(String[] args) {
        Cat cat = new Cat();
        Mouse mouse = new Mouse();
        Master master = new Master();
        cat.attach(mouse);
        cat.attach(master);
        cat.shout();
    }
}
