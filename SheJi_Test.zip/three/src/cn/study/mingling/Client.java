package cn.study.mingling;

public class Client {
    public static void main(String[] args) {
        Light light = new Light();
        Fan fan = new Fan();

        Command lightOn = new LightOnCommand(light);
        Command lightOff = new LightOffCommand(light);

        Command fanOn = new FanOnCommand(fan);
        Command fanOff = new FanOffCommand(fan);

        Switch s = new Switch(lightOn, lightOff);
        s.on();
        s.off();

        Switch s2 = new Switch(fanOn, fanOff);
        s2.on();
        s2.off();
    }
}
