package cn.study.mingling;

// Command�ӿ�
public interface Command {
    public void execute();
}