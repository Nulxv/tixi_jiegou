package cn.study.mingling;

// ������
public class Switch {
    private Command onCommand;
    private Command offCommand;

    public Switch(Command onCmd, Command offCmd) {
        this.onCommand = onCmd;
        this.offCommand = offCmd;
    }

    public void on() {
        onCommand.execute();
    }

    public void off() {
        offCommand.execute();
    }
}
