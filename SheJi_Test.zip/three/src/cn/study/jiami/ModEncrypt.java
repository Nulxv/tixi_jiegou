package cn.study.jiami;

//��ģ���ܲ���
class ModEncrypt implements EncryptStrategy {

    @Override
    public String encrypt(String text) {
        StringBuilder sb = new StringBuilder();
        for(char c : text.toCharArray()) {
            sb.append((char)(c % 10));
        }
        return sb.toString();
    }
}
