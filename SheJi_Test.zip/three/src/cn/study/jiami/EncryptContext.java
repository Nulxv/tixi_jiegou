package cn.study.jiami;

//������
class EncryptContext {

    private EncryptStrategy strategy;

    public void setStrategy(EncryptStrategy strategy) {
        this.strategy = strategy;
    }

    public String encrypt(String text) {
        return strategy.encrypt(text);
    }
}
