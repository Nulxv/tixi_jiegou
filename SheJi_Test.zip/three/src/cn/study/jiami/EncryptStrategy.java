package cn.study.jiami;

//���Խӿ�
interface EncryptStrategy {
    String encrypt(String text);
}
