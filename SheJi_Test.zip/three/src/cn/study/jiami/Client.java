package cn.study.jiami;

public class Client {

    public static void main(String[] args) {
        EncryptContext ctx = new EncryptContext();
        String text = "hello";
        ctx.setStrategy(new CaesarEncrypt());
        System.out.println(ctx.encrypt(text));
        ctx.setStrategy(new ModEncrypt());
        System.out.println(ctx.encrypt(text));
    }
}
