package cn.study.diedai;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

//�༶��
class Class implements Iterable<Student> {

    private ArrayList<Student> students;

    public Class() {
        students = new ArrayList<>();
    }

    public void addStudent(Student s) {
        students.add(s);
    }

    @Override
    public Iterator<Student> iterator() {
        Collections.sort(students, (s1, s2) -> s2.getAge() - s1.getAge());
        return new StudentIterator(students);
    }
}
