package cn.study.diedai;

import java.util.Iterator;

public class Client {
    public static void main(String[] args) {
        Class c = new Class();
        c.addStudent(new Student("John", 20));
        c.addStudent(new Student("Mary", 18));
        c.addStudent(new Student("Tom", 21));

        Iterator<Student> it = c.iterator();
        while (it.hasNext()) {
            Student s = it.next();
            System.out.println(s.getName() + "," + s.getAge());
        }
    }
}
