package cn.study.diedai;

import java.util.ArrayList;
import java.util.Iterator;

//������ʵ����
class StudentIterator implements Iterator<Student> {

    private ArrayList<Student> students;
    private int index = 0;

    public StudentIterator(ArrayList<Student> students) {
        this.students = students;
    }

    @Override
    public boolean hasNext() {
        return (index < students.size());
    }

    @Override
    public Student next() {
        Student s = students.get(index);
        index++;
        return s;
    }
}
