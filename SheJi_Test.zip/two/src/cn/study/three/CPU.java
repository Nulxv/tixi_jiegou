package cn.study.three;

//CPU子系统
public class CPU implements SubSystem {

    public void start() {
        System.out.println("CPU开始运行...");
    }

    public void end() {
        System.out.println("CPU结束运行。");
    }
}
