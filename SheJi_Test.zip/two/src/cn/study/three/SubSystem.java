package cn.study.three;

//子系统抽象类
public interface SubSystem {
    void start();
    void end();
}
