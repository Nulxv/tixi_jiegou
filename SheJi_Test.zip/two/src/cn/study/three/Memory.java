package cn.study.three;

//内存子系统
public class Memory implements SubSystem {

    public void start() {
        System.out.println("内存自检中...");
    }

    public void end() {
        System.out.println("内存自检结束。");
    }
}
