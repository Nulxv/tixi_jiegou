package cn.study.three;

//硬盘子系统
public class HardDisk implements SubSystem {

    public void start() {
        System.out.println("硬盘开始读取...");
    }

    public void end() {
        System.out.println("硬盘读取结束。");
    }
}
