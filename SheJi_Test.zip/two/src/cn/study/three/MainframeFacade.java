package cn.study.three;

//外观类
public class MainframeFacade {

    private SubSystem[] subSystems = {
            new Memory(),
            new CPU(),
            new HardDisk(),
            new OS()
    };

    public void start() {
        for (SubSystem subSystem : subSystems) {
            subSystem.start();
        }
    }

    public void end() {
        for (SubSystem subSystem : subSystems) {
            subSystem.end();
        }
    }
}
