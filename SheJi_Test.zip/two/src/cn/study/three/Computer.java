package cn.study.three;

//客户端类
public class Computer {
    public static void main(String[] args) {
        MainframeFacade facade = new MainframeFacade();
        facade.start();
        facade.end();
    }
}