package cn.study.three;

//操作系统子系统
public class OS implements SubSystem {

    public void start() {
        System.out.println("操作系统开始载入...");
    }

    public void end() {
        System.out.println("操作系统载入结束。");
    }
}