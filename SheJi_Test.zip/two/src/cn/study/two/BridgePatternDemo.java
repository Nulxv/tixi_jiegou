package cn.study.two;

public class BridgePatternDemo {

    public static void main(String[] args) {

        Implementor red = new RedImplementor();
        Implementor green = new GreenImplementor();

        Brush pencil = new PencilBrush();
        pencil.setImplementor(red);
        pencil.useBrush();

        Brush brushPen = new BrushPen();
        brushPen.setImplementor(green);
        brushPen.useBrush();

    }

}