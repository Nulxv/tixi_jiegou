package cn.study.two;

// RefinedAbstraction
public class PencilBrush extends Brush {

    public void useBrush() {
        //ʵ���ض�ҵ���߼�
        implementor.implement();
    }

}