package cn.study.two;

// RedImplementor
public class RedImplementor implements Implementor {

    public void implement() {
        System.out.println("ʵ�ֺ�ɫ");
    }

}
