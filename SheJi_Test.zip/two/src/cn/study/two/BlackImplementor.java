package cn.study.two;

// ConcreteImplementor
public class BlackImplementor implements Implementor {

    public void implement() {
        System.out.println("ʵ�ֺ�ɫ");
    }

}
