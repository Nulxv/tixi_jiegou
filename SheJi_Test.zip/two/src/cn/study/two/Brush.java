package cn.study.two;

// Abstraction
public abstract class Brush {

    protected Implementor implementor;

    public void setImplementor(Implementor implementor) {
        this.implementor = implementor;
    }

    public abstract void useBrush(); //����ҵ�񷽷�

}
