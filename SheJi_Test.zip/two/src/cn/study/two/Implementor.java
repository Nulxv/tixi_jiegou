package cn.study.two;

// Implementor
public interface Implementor {

    void implement();

}