package cn.study.two;

// GreenImplementor
public class GreenImplementor implements Implementor {

    public void implement() {
        System.out.println("ʵ����ɫ");
    }

}