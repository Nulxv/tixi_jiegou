package cn.study.three;

public interface Observer {
    void toDo();
}

