package cn.study.test;

public abstract class Person {
    public void PrintV(){

    }
}

