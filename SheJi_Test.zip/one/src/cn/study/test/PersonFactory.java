package cn.study.test;

public class PersonFactory {
    public static Person createPerson(String type) {
        if ("M".equals(type)) {
            return new Man();
        } else if ("W".equals(type)) {
            return new Woman();
        } else if ("R".equals(type)) {
            return new Robot();
        } else {
            return null;
        }
    }
}
