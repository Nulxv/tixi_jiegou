package cn.study.test;

public class Robot extends Person{
    public void PrintV(){
        System.out.println("创造了Robat");
    }
}
