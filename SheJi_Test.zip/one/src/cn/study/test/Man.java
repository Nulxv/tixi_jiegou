package cn.study.test;

public class Man extends Person{
    public void PrintV(){
        System.out.println("创造了Man");
    }
}
