package cn.study.test;

public class Woman extends Person{
    public void PrintV(){
        System.out.println("创造了Woman");
    }
}
