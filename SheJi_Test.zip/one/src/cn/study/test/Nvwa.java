package cn.study.test;

public class Nvwa {
    public static void main(String[] args) {
        Person man = PersonFactory.createPerson("M");
        man.PrintV();
        Person woman = PersonFactory.createPerson("W");
        woman.PrintV();
        Person robot = PersonFactory.createPerson("R");
        robot.PrintV();
    }
}
