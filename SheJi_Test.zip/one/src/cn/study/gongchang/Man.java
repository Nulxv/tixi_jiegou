package cn.study.gongchang;

public class Man extends Person{
}
