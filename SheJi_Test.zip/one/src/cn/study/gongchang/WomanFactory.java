package cn.study.gongchang;

public class WomanFactory implements PersonFactory {
    @Override
    public Person createPerson() {
        return new Woman();
    }
}
