package cn.study.gongchang;

public abstract class Person {

}
