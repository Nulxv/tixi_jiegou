package cn.study.gongchang;

public class RobotFactory implements PersonFactory {
    @Override
    public Person createPerson() {
        return new Robot();
    }
}
