package cn.study.gongchang;

public class Client {

    public static void main(String[] args) {
        Person man = Nvwa.createPerson("M");
        Person woman = Nvwa.createPerson("W");
        Person robot = Nvwa.createPerson("R");

        System.out.println(man.getClass().getSimpleName());
        System.out.println(woman.getClass().getSimpleName());
        System.out.println(robot.getClass().getSimpleName());
    }

}
