package cn.study.gongchang;

public class Woman extends Person{
    
}
