package cn.study.gongchang;

public class ManFactory implements PersonFactory {
    @Override
    public Person createPerson() {
        return new Man();
    }
}
