package cn.study.gongchang;

public interface PersonFactory {
    Person createPerson();
}
