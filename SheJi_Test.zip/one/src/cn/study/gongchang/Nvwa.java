package cn.study.gongchang;

    public class Nvwa {
        public static Person createPerson(String type) {
            PersonFactory factory;
            if ("M".equals(type)) {
                factory = new ManFactory();
            } else if ("W".equals(type)) {
                factory = new WomanFactory();
            } else if ("R".equals(type)) {
                factory = new RobotFactory();
            } else {
                factory = null;
            }
            return factory.createPerson();
        }
    }
