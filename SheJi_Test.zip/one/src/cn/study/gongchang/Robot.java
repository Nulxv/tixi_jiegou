package cn.study.gongchang;

public class Robot extends Person {

}
