package cn.study.chouxaing;

public class Client {

    public static void main(String[] args) {
        // 创建海尔工厂
        AbstractFactory haierFactory = new HaierFactory();
        // 海尔工厂生产海尔电视机
        TV haierTV = haierFactory.createTV();
        haierTV.show();
        // 海尔工厂生产海尔空调
        AirCondition haierAirCondition = haierFactory.createAirCondition();
        haierAirCondition.changeTemperature();

        // 创建TCL工厂
        AbstractFactory tclFactory = new TCLFactory();
        // TCL工厂生产TCL电视机
        TV tclTV = tclFactory.createTV();
        tclTV.show();
        // TCL工厂生产TCL空调
        AirCondition tclAirCondition = tclFactory.createAirCondition();
        tclAirCondition.changeTemperature();
    }

}
