package cn.study.chouxaing;

// 海尔工厂
public class HaierFactory implements AbstractFactory {

    public TV createTV() {
        return new HaierTV();
    }

    public AirCondition createAirCondition() {
        return new HaierAirCondition();
    }

}
