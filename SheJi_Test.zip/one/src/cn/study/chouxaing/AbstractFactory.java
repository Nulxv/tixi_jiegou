package cn.study.chouxaing;

// 抽象工厂接口
public interface AbstractFactory {
    TV createTV();
    AirCondition createAirCondition();
}
