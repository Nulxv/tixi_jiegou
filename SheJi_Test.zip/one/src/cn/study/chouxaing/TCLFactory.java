package cn.study.chouxaing;

// TCL工厂
public class TCLFactory implements AbstractFactory {

    public TV createTV() {
        return new TCLTV();
    }

    public AirCondition createAirCondition() {
        return new TCLAirCondition();
    }

}
