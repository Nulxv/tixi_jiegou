package cn.study.chouxaing;

// 海尔电视机
public class HaierTV implements TV {
    public void show() {
        System.out.println("显示海尔电视机");
    }
}
