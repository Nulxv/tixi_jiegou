package cn.study.chouxaing;

// TCL空调
public class TCLAirCondition implements AirCondition {
    public void changeTemperature() {
        System.out.println("改变TCL空调温度");
    }
}
