package cn.study.chouxaing;

// 空调
public interface AirCondition {
    void changeTemperature();
}
