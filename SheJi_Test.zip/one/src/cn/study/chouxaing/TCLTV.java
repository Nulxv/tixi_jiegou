package cn.study.chouxaing;

// TCL电视机
public class TCLTV implements TV {
    public void show() {
        System.out.println("显示TCL电视机");
    }
}
