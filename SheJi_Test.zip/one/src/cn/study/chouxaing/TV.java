package cn.study.chouxaing;

// 电视机
public interface TV {
    public void show();
}
