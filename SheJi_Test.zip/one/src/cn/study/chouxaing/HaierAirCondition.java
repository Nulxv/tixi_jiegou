package cn.study.chouxaing;

// 海尔空调
public class HaierAirCondition implements AirCondition {
    public void changeTemperature() {
        System.out.println("改变海尔空调温度");
    }
}
