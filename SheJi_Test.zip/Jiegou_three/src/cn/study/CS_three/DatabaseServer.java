package cn.study.CS_three;

import java.util.HashMap;
import java.util.Map;

public class DatabaseServer {
    private static Map<String, String> contacts = null;

    private static Map<String, String> initializeContacts() {
        Map<String, String> initialContacts = new HashMap<>();
        initialContacts.put("Alice", "123456789");
        initialContacts.put("Bob", "987654321");
        initialContacts.put("Charlie", "567890123");
        return initialContacts;
    }

    public static Map<String, String> getContacts() {
        if (contacts == null) {
            contacts = initializeContacts();
        }
        return contacts;
    }

    public static void addContact(String name, String phone) {
        getContacts().put(name, phone);
    }

    public static void updateContact(String name, String phone) {
        getContacts().put(name, phone);
    }

    public static void deleteContact(String name) {
        getContacts().remove(name);
    }
}
