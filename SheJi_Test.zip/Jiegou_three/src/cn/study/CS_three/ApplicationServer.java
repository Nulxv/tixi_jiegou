package cn.study.CS_three;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Map;

public class ApplicationServer {
    public static void main(String[] args) {
        ServerSocket serverSocket = null;

        try {
            serverSocket = new ServerSocket(12346);
            System.out.println("�ȴ��ͻ�������...");

            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("���ӵ�ַ��" + clientSocket.getInetAddress());

                handleClient(clientSocket);
            }
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            try {
                if (serverSocket != null) {
                    serverSocket.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private static void sendContacts(ObjectOutputStream oos) throws IOException {
        Map<String, String> contacts = DatabaseServer.getContacts();
        oos.writeObject(contacts);
    }

    private static void handleClient(Socket clientSocket) throws IOException, ClassNotFoundException {
        ObjectInputStream ois = new ObjectInputStream(clientSocket.getInputStream());
        ObjectOutputStream oos = new ObjectOutputStream(clientSocket.getOutputStream());

        try {
            Map<String, String> contacts;
            Map<String, Object> request = (Map<String, Object>) ois.readObject();

            String action = (String) request.get("action");

            switch (action) {
                case "get_contacts":
                    sendContacts(oos);
                    break;

                case "add_contact":
                    String addName = (String) request.get("name");
                    String addPhone = (String) request.get("phone");
                    DatabaseServer.addContact(addName, addPhone);
                    sendContacts(oos);
                    break;

                case "update_contact":
                    String updateName = (String) request.get("name");
                    String updatePhone = (String) request.get("phone");
                    DatabaseServer.updateContact(updateName, updatePhone);
                    sendContacts(oos);
                    break;

                case "delete_contact":
                    String deleteName = (String) request.get("name");
                    DatabaseServer.deleteContact(deleteName);
                    sendContacts(oos);
                    break;

                default:
                    oos.writeObject("Unknown action");
                    break;
            }

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            ois.close();
            oos.close();
            clientSocket.close();
            System.out.println("Connection closed");
        }
    }
}
