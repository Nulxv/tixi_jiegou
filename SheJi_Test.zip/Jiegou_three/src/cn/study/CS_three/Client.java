package cn.study.CS_three;

import java.io.*;
import java.net.Socket;
import java.util.Map;

public class Client {
    public static void main(String[] args) {
        Socket clientSocket = null;

        try {
            clientSocket = new Socket("localhost", 12346);

            ObjectOutputStream oos = new ObjectOutputStream(clientSocket.getOutputStream());
            ObjectInputStream ois = new ObjectInputStream(clientSocket.getInputStream());

            // ��ȡͨѶ¼
            Map<String, String> contacts = getContacts(oos, ois);
            System.out.println("ͨѶ¼��" + contacts);

            // ��������ϵ��
            addContact(oos, ois, "Dovid", "123456789");
            System.out.println("Contact added successfully");

            // �鿴��ϵ��
            Thread.sleep(1000);
            contacts = getContacts(oos, ois);
            System.out.println("ͨѶ¼��" + contacts);

            // �޸���ϵ����Ϣ
            updateContact(oos, ois, "Dovid", "987654321");
            System.out.println("Contact updated successfully");

            // �鿴��ϵ��
            contacts = getContacts(oos, ois);
            System.out.println("ͨѶ¼��" + contacts);

            // ɾ����ϵ��
            deleteContact(oos, ois, "David");
            System.out.println("Contact deleted successfully");

            // �鿴��ϵ��
            contacts = getContacts(oos, ois);
            System.out.println("ͨѶ¼��" + contacts);

        } catch (IOException | ClassNotFoundException | InterruptedException e) {
            System.err.println("Exception in Client:");
            e.printStackTrace();
        }
        finally {
            try {
                if (clientSocket != null) {
                    clientSocket.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private static Map<String, String> getContacts(ObjectOutputStream oos, ObjectInputStream ois) throws IOException, ClassNotFoundException {
        Map<String, Object> request = Map.of("action", "get_contacts");
        oos.writeObject(request);
        return (Map<String, String>) ois.readObject();
    }

    private static void addContact(ObjectOutputStream oos, ObjectInputStream ois, String name, String phone) throws IOException, ClassNotFoundException {
        Map<String, Object> request = Map.of("action", "add_contact", "name", name, "phone", phone);
        oos.writeObject(request);
        oos.flush(); // �ֶ�ˢ��
        // �ȴ�����������Ӧ
        ois.readObject();
    }


    private static void updateContact(ObjectOutputStream oos, ObjectInputStream ois, String name, String phone) throws IOException, ClassNotFoundException {
        Map<String, Object> request = Map.of("action", "update_contact", "name", name, "phone", phone);
        oos.writeObject(request);
        // �ȴ�����������Ӧ
        ois.readObject();
    }

    private static void deleteContact(ObjectOutputStream oos, ObjectInputStream ois, String name) throws IOException, ClassNotFoundException {
        Map<String, Object> request = Map.of("action", "delete_contact", "name", name);
        oos.writeObject(request);
        // �ȴ�����������Ӧ
        ois.readObject();
    }
}
