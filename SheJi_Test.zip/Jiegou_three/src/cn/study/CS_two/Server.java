package cn.study.CS_two;

import java.io.*;
import java.net.*;
import java.util.HashMap;
import java.util.Map;

public class Server {
    public static void main(String[] args) {
        ServerSocket serverSocket = null;

        try {
            serverSocket = new ServerSocket(12345);
            System.out.println("�ȴ��ͻ�������...");

            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("���ӵ�ַ��" + clientSocket.getInetAddress());

                ObjectInputStream ois = new ObjectInputStream(clientSocket.getInputStream());
                ObjectOutputStream oos = new ObjectOutputStream(clientSocket.getOutputStream());

                try {
                    Map<String, String> contacts;
                    Map<String, Object> request = (Map<String, Object>) ois.readObject();

                    String action = (String) request.get("action");

                    switch (action) {
                        case "get_contacts":
                            contacts = getContacts();
                            oos.writeObject(contacts);
                            break;

                        case "add_contact":
                            Map<String, String> newContact = (Map<String, String>) request.get("contact");
                            String addResult = addContact(newContact);
                            oos.writeObject(addResult);
                            break;

                        case "update_contact":
                            Map<String, String> updatedContact = (Map<String, String>) request.get("contact");
                            String updateResult = updateContact(updatedContact);
                            oos.writeObject(updateResult);
                            break;

                        case "delete_contact":
                            String contactName = (String) request.get("name");
                            String deleteResult = deleteContact(contactName);
                            oos.writeObject(deleteResult);
                            break;

                        default:
                            oos.writeObject("Unknown action");
                            break;
                    }

                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                } finally {
                    ois.close();
                    oos.close();
                    clientSocket.close();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (serverSocket != null) {
                    serverSocket.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private static Map<String, String> getContacts() {
        Map<String, String> contacts = new HashMap<>();
        contacts.put("Alice", "123456789");
        contacts.put("Bob", "987654321");
        contacts.put("Charlie", "567890123");
        return contacts;
    }

    private static String addContact(Map<String, String> newContact) {
        return "Contact added successfully";
    }

    private static String updateContact(Map<String, String> updatedContact) {
        return "Contact updated successfully";
    }

    private static String deleteContact(String contactName) {
        return "Contact deleted successfully";
    }
}

