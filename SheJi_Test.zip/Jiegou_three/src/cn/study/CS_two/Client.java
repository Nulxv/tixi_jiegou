package cn.study.CS_two;

import java.io.*;
import java.net.*;
import java.util.Map;

public class Client {
    public static void main(String[] args) {
        Socket clientSocket = null;

        try {
            clientSocket = new Socket("localhost", 12345);

            ObjectOutputStream oos = new ObjectOutputStream(clientSocket.getOutputStream());
            ObjectInputStream ois = new ObjectInputStream(clientSocket.getInputStream());

            // ��ȡͨѶ¼
            Map<String, String> contacts = getContacts(oos, ois);
            System.out.println("ͨѶ¼��" + contacts);

            // ��������ϵ��
            Map<String, String> newContact = Map.of("name", "David", "phone", "123456789");
            String addResult = addContact(oos, ois, newContact);
            System.out.println(addResult);

            // �鿴��ϵ��
            contacts = getContacts(oos, ois);
            System.out.println("ͨѶ¼��" + contacts);

            // �޸���ϵ����Ϣ
            Map<String, String> updatedContact = Map.of("name", "David", "phone", "987654321");
            String updateResult = updateContact(oos, ois, updatedContact);
            System.out.println(updateResult);

            // �鿴��ϵ��
            contacts = getContacts(oos, ois);
            System.out.println("ͨѶ¼��" + contacts);

            // ɾ����ϵ��
            String deleteName = "David";
            String deleteResult = deleteContact(oos, ois, deleteName);
            System.out.println(deleteResult);

            // �鿴��ϵ��
            contacts = getContacts(oos, ois);
            System.out.println("ͨѶ¼��" + contacts);

        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            try {
                if (clientSocket != null) {
                    clientSocket.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private static Map<String, String> getContacts(ObjectOutputStream oos, ObjectInputStream ois) throws IOException, ClassNotFoundException {
        Map<String, Object> request = Map.of("action", "get_contacts");
        oos.writeObject(request);
        return (Map<String, String>) ois.readObject();
    }

    private static String addContact(ObjectOutputStream oos, ObjectInputStream ois, Map<String, String> newContact) throws IOException, ClassNotFoundException {
        Map<String, Object> request = Map.of("action", "add_contact", "contact", newContact);
        oos.writeObject(request);
        return (String) ois.readObject();
    }

    private static String updateContact(ObjectOutputStream oos, ObjectInputStream ois, Map<String, String> updatedContact) throws IOException, ClassNotFoundException {
        Map<String, Object> request = Map.of("action", "update_contact", "contact", updatedContact);
        oos.writeObject(request);
        return (String) ois.readObject();
    }

    private static String deleteContact(ObjectOutputStream oos, ObjectInputStream ois, String contactName) throws IOException, ClassNotFoundException {
        Map<String, Object> request = Map.of("action", "delete_contact", "name", contactName);
        oos.writeObject(request);
        return (String) ois.readObject();
    }
}
