<!-- 关于我们页面 -->
<template>
<div class="user-manage">
<json-excel
          class="export-excel-wrapper"
          :data="order"
          :fields="json_fields"
          name="商品销量数据导出.xls"
        >
 <span>导出</span>
  </json-excel>
<el-table
    :data="order"
    border
    style="width: 100%">
    <el-table-column
      prop="title"
      label="商品名称"
      width="180">
    </el-table-column>
    <el-table-column
      prop="sum"
      label="总销售量"
      width="180">
    </el-table-column>
    <el-table-column
      prop="ownName"
      label="卖家姓名"
      width="180">
    </el-table-column>
    <el-table-column
      prop="address"
      label="地址">
    </el-table-column>
  </el-table>
</div>
</template>
<script>


import {   selectsumorder } from "../api/order";
import JsonExcel from 'vue-json-excel';   

export default {
     components: { JsonExcel },
    data() {
        return {
          order:[],
          json_fields:{
            商品名称:"title",
            销售总额:"sum",
            卖家姓名:"ownname",
            地址:"address",
          }
         }
    },
    mounted() { },
    methods: {
      getOrder() {
      selectsumorder({})
      .then((res) => {
          this.order = res.data
        })
        .catch((err) => {
          console.log(err);
        });
    },
    },
    created() {  
   this.getOrder()
  },
}
</script>

<style lang="less" scoped>
.user-manage {
  width: 1100px;
  background: #fff;
  margin: 10px auto;
  padding: 10px 20px;
  .manager-change-user-info {
    .el-dialog {
      width: 500px;
      .el-dialog__body {
        height: 400px;
        .user-info {
          width: 400px;
          padding: 0;
          .manager-change-name,
          .manager-change-password,
          .manager-change-phone,
          .manager-change-address {
            .el-form-item__label {
              width: 100px !important;
            }
            width: 400px;
            margin-right: 200px;
          }
        }
      }
    }
  }
}
</style>
