package com.qst.crop.service;

import com.qst.crop.entity.Bank;

import java.util.List;

public interface BankService {

    List<Bank> selectAllBank();

}
