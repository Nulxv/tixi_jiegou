package com.qst.crop;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.constraints.Min;

@RestController
@RequestMapping("/api/income-tax")
public class IncomeTaxController {

    @PostMapping("/calculate")
    public ResponseEntity<Double> calculateIncomeTax(@RequestBody @Min(0) double income) {
        try {
            // 在这里实现更复杂的个人所得税的计算逻辑
            // 这里仍然简单返回一个固定值，实际应用中需要根据税法规则进行计算
            double tax = calculateTax(income); // 自定义计算方法
            return new ResponseEntity<>(tax, HttpStatus.OK);
        } catch (Exception e) {
            // 在实际应用中可能需要记录错误日志
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // 自定义计算个人所得税的方法
    private double calculateTax(double income) {
        // 实际应用中，这里应该根据税法规则计算个人所得税
        // 这里仍然简单返回一个固定值，实际应用中需要根据税法规则进行计算
        return income * 0.2; // 假设税率为20%
    }
}
